**Hestia Moving Components Limitations**

The purpose of this document is to compute the limitations on imaging
speed imposed by each component of the Hestia system, specifically the
ETLs, SMs, and Andor camera.

1.  ETLs

    a.  5D (-2 -- 3 dpt) with 5ms response time and 25ms settling time.
        So either 5ms (unsettled) or 30ms (settled) to adjust the focal
        length.\
        ![](media/5dfb19415df3473bb81ff2056b0f31eabf1a2f32.png){width="5.0in"
        height="2.3333333333333335in"}

    b.  20D (-10-10 dpt) with 7ms response time and 47 ms total settled
        time.\
        ![](media/204021effc487d00b06d2d2d4c80a4bb830d9a5b.png){width="5.0in"
        height="2.1770833333333335in"}

    c.  Due to lens operation method, seems like ETLs can pretty much
        respond to any adjustment in the same amount of time- not based
        on adjustment distance

2.  Steering Mirrors

    a.  AWAITING CONFIRMATION THAT THE FOLLOWING SM SPECS ARE FOR THE
        CORRECT MODEL-GOT MODEL NUMBER FROM CHAD'S DIONYSUS
        DOCUMENTATION (SN 3289). Hestia uses mirrors SN 3347 and SN 3303
        -- look identical as far as I can tell, but they may not be same
        model.\
        ![](media/80bdad76aa9e8e54e575a779e043a077f0d3860a.png){width="5.0in"
        height="3.9791666666666665in"}

    b.  According to 1" spec sheet, 1 milliradian step has a response
        time of 5ms or less. Seems to cap us out at about 200fps.

    c.  Both SMs cap at +/- 1.5 degrees. Limitations depend on
        magnification. See overleaf doc for computations of this at 60X
        magnification.

3.  Andor Camera

    a.  Presuming that we are using a USB 3.0 with rolling shutter and
        540 MHz readout speed, we are capable of 1578 fps on a 128X128
        ROI.

> ![](media/f81fbd63cbd981831e4ae78104b6f6003d6fda30.png){width="5.0in"
> height="3.8854166666666665in"}
>
> Other modes have even faster framerates depending on ROI size-up to
> 26,000 fps. Clearly not the limiting factor here, since we hit 200fps
> easily with half the sceen being utilized.\
> ![](media/83217524d9ce16dd5f7d8c901932adfdd2e2b7cf.png){width="4.276258748906387in"
> height="5.864584426946632in"}

4.  Laser

    a.  Probably not a factor, since we can either just leave the laser
        on continuously for high-speed imaging if it is too limiting.

So it would seem that the system is capable of ≥200 fps, which is
limited exclusively by the Steering Mirrors' response time, except when
it comes to focal plane changes, which will take between 5ms and 25ms
depending on whether or not we need to wait for the ETL to settle . This
is probably not too important for large scans since the etl will settle
in the first few frames of the new focal plane level. More important for
small width scans, since if number of frames per layer is not \>\>5,
then the lens will be unsettled for the majority of the frames instead
of just the first few, potentially having significant consequences for
image quality outcomes.

Lasers:

I haven't been able to find any data for the light engine, but the OBIS
lasers themselves are all theoretically capable of very high on-off
cycling rates attording to data sheets from OBIS, usually on the order
of at least 500kHz. As a result, barring an intermediate hardware
latency, they are unlikely to ever impede on our scan speed and in fact
are by far the most responsive part of the system on paper.

AOTF (optical engine) also has very rapid response times. Manufacturer's
table is below, but in summary it is very fast. Acoutsto-optic
device-sets up acoustic field in system. Pressure wave of sound pushes
atoms around in crystal, changing local index of refraction. The peaks
and troughs create a blazed grating of sorts which scatters the light.
Works really well for us b/c it can independently tune the intensity of
each input wavelength on a μs timescale, which is kind of insane. What
exactly does the extinction ratio mean? \>50dB means what?\
![](media/844f3d21efd765be08213597d3587c7f1bd351a5.png){width="5.0in"
height="3.8854166666666665in"}

**[Parallel track: stuff to figure out in-between looking at code
etc.]{.mark}**\
[Important but difficult question: what is the signal/noise ratio in the
end? What is the threshold/what is good enough? For flourescence, want
to signal noise ratio/pixel- look into exactly what this means in the
context of flourescent microscopy in particular.]{.mark}\
[In the end- this discussion is going to end up at how much light we are
producing in the sample? How bright is laser and how focused is it and
how do we handle bleaching/phototox?]{.mark}\
[Should look at papers and what not-what are practical considerations
within their data collection? Maybe open up the ol' literature table
again and figure out max intensity at specimine. We can compute this via
using exposure rate, laser power entering objective, beam parameters,
etc. When we collect data, bleaching ends up being sort of the "final
boss" since they dim pretty immediately.]{.mark}\
[Be on the lookout for novel techs -- think stuff like diamond
vacancies, etc. That provide a more robust imaging over time.]{.mark}\
[Also add group parameter --want to know where author is
working.]{.mark}\
[Main point-what are people doing? Get a sense for the different players
and what their imaging parameters, what signal --to-noise ratios are,
etc.]{.mark}\
[Look into microsocpy course for this summer!]{.mark}\
[Note flourophores have X-section-gives probablity of being hit by a
photon at a given intensity of light. Can then figure out once absorb
what is probability over time of the photon emitting a photon. And what
is the probability that this photon finds its way into the microscope,
through the objective and filter sets and into the camera lens. Should
eventually track all of this down in details!]{.mark}
