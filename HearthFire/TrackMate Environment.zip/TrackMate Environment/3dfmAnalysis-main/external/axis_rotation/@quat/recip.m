function p = recip(q)
p = conj(q)*(1/norm(q)^2);