function p = norm(q,r)
if nargin == 1
   r = 2;
end
p = norm(vector(q),r);

