function [visc, visc_err] = pan_compute_viscosity_heatmap(metadata, spec_tau, msdmap, msdmap_err)

kB = 1.3806e-23;
T = 296; % temperature in Kelvin 

bead_radius = metadata.plate.bead.diameter ./ (2 * 1e6);
bead_radius = pan_array2plate(bead_radius);

visc = (2 * kB * T * spec_tau) ./ (3 * pi * bead_radius .* 10.^msdmap);
visc_with_err = (2 * kB * T * spec_tau) ./ (3 * pi * bead_radius .* 10.^(msdmap+msdmap_err));

visc_err = abs(visc_with_err - visc);

return;
