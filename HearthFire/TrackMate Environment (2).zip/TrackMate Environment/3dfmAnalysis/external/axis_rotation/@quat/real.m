function p = real(q)
p = q.r;