function p = uplus(q)
p = quat(q);