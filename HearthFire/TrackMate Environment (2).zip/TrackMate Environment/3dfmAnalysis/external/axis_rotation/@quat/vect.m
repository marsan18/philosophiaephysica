function v = vect(q)
% vect(q) -- returns the vector part of quaternion q.

v = q.v;