function folder = uigetfolder_win32_compiler_test
% Test for uigetfolder with the MATLAB compiler (R12)

folder = uigetfolder_standalone;

disp(folder)
%-----------------------------------------------------


